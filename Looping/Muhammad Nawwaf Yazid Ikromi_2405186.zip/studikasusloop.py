#Muhammad Nawwaf Yazid Ikromi
#NIM: 2405186
#Kelas: RPL 1A

for i in range (1,51):
    if  i % 5 == 0:
        print("pass")
    else:
        print(i)
