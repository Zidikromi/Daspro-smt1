#Muhammad Nawwaf Yazid Ikromi
#NIM: 2405186
#Kelas: RPL 1A

i = int(input("Masukkan angka: "))
total = 0
while i > 0:
    total += i
    i = int(input("Masukkan angka: "))
print(f"Total: {total}")