#Muhammad Nawwaf Yazid Ikromi
#NIM: 2405186
#Kelas: RPL 1A

x = 0
for i in range(10):
    x += i
    print(f"{x} + {i+1} = {x+i+1}")




