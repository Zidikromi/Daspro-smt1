#Muhammad Nawwaf Yazid Ikromi
#NIM: 2405186
#Kelas: RPL 1A

nilaisiswa = [78,90,56,98,65,38,42,74,89,90]

inputguru = input("Masukkan no urut: ")

print(f"No urut {inputguru} Nilai nya adalah {nilaisiswa[int(inputguru)-1]}")