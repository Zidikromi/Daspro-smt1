#Muhammad Nawwaf Yazid Ikromi
#NIM: 2405186
#Kelas: RPL 1A

menit = 13
detik = 37

totaldetik = menit * 60 + detik

print(f"Mobil balap melaju selama {totaldetik} detik dalam 1 putaran" )
