#Muhammad Nawwaf Yazid Ikromi
#NIM: 2405186
#Kelas: RPL 1A

panjang = 10
lebar = 15
kedalaman = 2 
volume = panjang * lebar * kedalaman
print(f"Volume maksimal air adalah {volume} meter kubik" )