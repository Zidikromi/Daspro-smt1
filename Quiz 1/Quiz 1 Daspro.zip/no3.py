#Muhammad Nawwaf Yazid Ikromi
#NIM: 2405186
#Kelas: RPL 1A

panjang = 10
tinggi = 3.5
lebar = 8

luasdinding = 2 * (panjang * tinggi) + 2 * (lebar * tinggi)
harga = 580000
biaya = luasdinding * harga

print(f"Biaya pembuatan dinding adalah {biaya} rupiah" )
